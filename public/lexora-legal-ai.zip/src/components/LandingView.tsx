import React, { useState } from 'react';
import { SUGGESTED_RESEARCH_PROMPTS } from '../data/mockLegalArchive';
import { Search, Compass, Scale, Volume2, VolumeX, CornerDownLeft, Download, Sliders, Cpu } from 'lucide-react';
import { ArchiveSettingsModal } from './ArchiveSettingsModal';
import { sound } from '../utils/audio';

interface LandingViewProps {
  onSearch: (query: string) => void;
  onSelectPrompt: (query: string) => void;
  onFocusChange: (focused: boolean) => void;
  onQueryChange: (query: string) => void;
  audioEnabled: boolean;
  onToggleAudio: () => void;
  onOpenGraphDirect?: () => void;
  onOpenSelfLearning?: () => void;
}

export const LandingView: React.FC<LandingViewProps> = ({
  onSearch,
  onSelectPrompt,
  onFocusChange,
  onQueryChange,
  audioEnabled,
  onToggleAudio,
  onOpenGraphDirect,
  onOpenSelfLearning
}) => {
  const [inputValue, setInputValue] = useState('');
  const [isFocused, setIsFocused] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputValue.trim()) {
      sound.playArchivePulse();
      onSearch(inputValue.trim());
    }
  };

  const handlePromptClick = (title: string) => {
    sound.playArchivePulse();
    onSelectPrompt(title);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setInputValue(val);
    onQueryChange(val);
  };

  return (
    <div className="relative z-10 min-h-screen flex flex-col justify-between px-6 sm:px-12 py-8 max-w-6xl mx-auto pointer-events-none">
      {/* Top Archival Navigation Bar — Minimalist & Clean */}
      <header className="flex items-center justify-between w-full pointer-events-auto">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-lg border border-[#c5a880]/30 bg-[#2a0d14]/40 flex items-center justify-center shadow-sm">
            <Scale className="w-4 h-4 text-[#d4af37]" />
          </div>
          <div>
            <span className="font-['Cinzel'] tracking-[0.28em] text-base text-[#f5f2eb] font-semibold block">
              LEXORA
            </span>
            <p className="text-[10px] tracking-[0.22em] text-[#9e988f] uppercase font-light">
              The Living Law Archive
            </p>
          </div>
        </div>

        {/* Clean Controls (No clutter, all specs moved to Settings modal) */}
        <div className="flex items-center space-x-2 sm:space-x-3">
          {onOpenSelfLearning && (
            <button
              id="btn-landing-self-learning"
              onClick={onOpenSelfLearning}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg border border-emerald-500/40 bg-emerald-950/40 hover:bg-emerald-900/50 text-emerald-300 transition-all text-xs tracking-wider font-['Plus_Jakarta_Sans'] shadow-sm"
              title="Self-Learning RAG Intelligence & Corpus Ingestion"
            >
              <Cpu className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
              <span className="hidden sm:inline">Self-Learning RAG</span>
            </button>
          )}

          {onOpenGraphDirect && (
            <button
              onClick={onOpenGraphDirect}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg border border-[#c5a880]/30 bg-[#171a22]/70 text-[#c5a880] hover:bg-[#c5a880]/15 hover:border-[#c5a880]/60 transition-all text-xs tracking-wider font-['Plus_Jakarta_Sans']"
              title="Explore Corpus Topology"
            >
              <Compass className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Knowledge Atlas</span>
            </button>
          )}

          <a
            href="/lexora-legal-ai.zip"
            download="lexora-legal-ai.zip"
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg border border-[#c5a880]/50 bg-[#42121e]/40 hover:bg-[#42121e] text-[#faedd0] hover:border-[#c5a880] transition-all text-xs tracking-wider font-['Plus_Jakarta_Sans'] font-medium"
            title="Download Source Code as ZIP"
          >
            <Download className="w-3.5 h-3.5 text-[#d4af37]" />
            <span className="hidden sm:inline">Download ZIP</span>
          </a>

          <button
            onClick={() => setIsSettingsOpen(true)}
            className="p-2 rounded-lg border border-white/10 bg-[#14161d]/60 text-[#9e988f] hover:text-[#f5f2eb] hover:border-[#c5a880]/40 transition-colors"
            title="Archive Specifications & Telemetry"
          >
            <Sliders className="w-4 h-4" />
          </button>

          <button
            onClick={onToggleAudio}
            className="p-2 rounded-lg border border-white/10 bg-[#14161d]/60 text-[#9e988f] hover:text-[#f5f2eb] hover:border-[#c5a880]/40 transition-colors"
            title={audioEnabled ? "Disable Archival Acoustic Resonance" : "Enable Archival Acoustic Resonance"}
          >
            {audioEnabled ? <Volume2 className="w-4 h-4 text-[#c5a880]" /> : <VolumeX className="w-4 h-4" />}
          </button>
        </div>
      </header>

      {/* Hero Research Portal Central Content */}
      <main className="my-auto py-12 flex flex-col items-center text-center max-w-3xl mx-auto w-full pointer-events-auto">
        {/* Big Statement: Ask the Law. */}
        <h1 className="font-['Cinzel'] text-4xl sm:text-6xl md:text-7xl font-bold tracking-tight text-[#f5f2eb] mb-5 leading-[1.08]">
          Ask the Law.
        </h1>

        {/* Editorial Subtitle */}
        <p className="font-['Newsreader'] italic text-lg sm:text-xl md:text-2xl text-[#c2bcae] max-w-2xl mb-10 leading-relaxed font-normal">
          Explore legislation, cases and legal knowledge through an intelligent research interface connected to a living digital archive.
        </p>

        {/* Large Elegant Research Portal Search Bar */}
        <div className="w-full relative group">
          <form
            onSubmit={handleSubmit}
            className={`relative flex items-center w-full transition-all duration-300 rounded-xl border ${
              isFocused
                ? 'border-[#c5a880] shadow-[0_0_35px_rgba(197,168,128,0.18)] bg-[#101217]'
                : 'border-white/15 hover:border-[#c5a880]/50 bg-[#111318]/90'
            } backdrop-blur-xl p-2 sm:p-2.5`}
          >
            {/* Search icon */}
            <div className="pl-3 pr-2 text-[#c5a880]">
              <Search className="w-5 h-5 sm:w-6 sm:h-6 opacity-80" />
            </div>

            {/* Input field */}
            <input
              type="text"
              value={inputValue}
              onChange={handleInputChange}
              onFocus={() => {
                setIsFocused(true);
                onFocusChange(true);
              }}
              onBlur={() => {
                setIsFocused(false);
                onFocusChange(false);
              }}
              placeholder="What are you looking for?"
              className="w-full bg-transparent px-2 py-3 text-base sm:text-lg text-[#f5f2eb] placeholder-[#8c857b] font-['Newsreader'] focus:outline-none tracking-wide"
            />

            {/* Return / Launch Button */}
            <button
              type="submit"
              disabled={!inputValue.trim()}
              className={`flex items-center space-x-1.5 px-4 sm:px-5 py-2.5 rounded-lg font-['Plus_Jakarta_Sans'] text-xs uppercase tracking-wider font-semibold transition-all ${
                inputValue.trim()
                  ? 'bg-gradient-to-r from-[#42121e] to-[#6b1d2f] text-[#faedd0] border border-[#c5a880]/40 shadow-md hover:brightness-110 active:scale-95'
                  : 'bg-white/5 text-white/30 border border-white/5 cursor-not-allowed'
              }`}
            >
              <span>Search</span>
              <CornerDownLeft className="w-3.5 h-3.5" />
            </button>
          </form>

          {/* Focal indicator below search field */}
          <div className="flex items-center justify-between px-3 pt-2 text-[11px] text-[#9e988f]">
            <span className="flex items-center space-x-1.5 tracking-widest uppercase text-[10px] text-[#8c857b]">
              <span className={`w-1.5 h-1.5 rounded-full ${isFocused ? 'bg-[#c5a880] animate-ping' : 'bg-[#c5a880]/40'}`} />
              <span>{isFocused ? 'Archive Inquisitor Focused' : 'Search the Living Archive'}</span>
            </span>
            <span className="hidden sm:inline font-mono text-[10px] text-[#706b64]">
              Press Enter ↵
            </span>
          </div>
        </div>

        {/* Floating Suggested Archival Prompts */}
        <div className="w-full mt-12">
          <div className="flex items-center justify-between mb-4">
            <span className="text-[11px] font-['Plus_Jakarta_Sans'] tracking-[0.2em] text-[#c5a880]/80 uppercase">
              ARCHIVAL RESEARCH INQUIRIES
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 text-left">
            {SUGGESTED_RESEARCH_PROMPTS.map((prompt, idx) => (
              <div
                key={idx}
                onClick={() => handlePromptClick(prompt.title)}
                data-interactive="true"
                className="group relative p-4 rounded-lg border border-white/10 hover:border-[#c5a880]/60 bg-[#13151c]/70 hover:bg-[#1a1318]/80 backdrop-blur-md transition-all duration-300 cursor-pointer overflow-hidden transform hover:-translate-y-0.5 shadow-sm"
              >
                {/* Subtle corner ornament */}
                <div className="absolute top-0 right-0 w-8 h-8 pointer-events-none opacity-20 group-hover:opacity-60 transition-opacity">
                  <div className="w-full h-full border-t border-r border-[#c5a880]" />
                </div>

                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] tracking-[0.22em] text-[#c5a880] font-semibold font-['Plus_Jakarta_Sans'] uppercase">
                    {prompt.domain}
                  </span>
                  <span className="text-[10px] font-mono text-[#8a8479]">
                    {prompt.sectionSnippet}
                  </span>
                </div>

                <h3 className="font-['Newsreader'] text-base text-[#f5f2eb] font-normal group-hover:text-[#faedd0] transition-colors leading-snug">
                  {prompt.title}
                </h3>

                <div className="mt-3 flex items-center space-x-1.5">
                  {prompt.keyTerms.map((term, tIdx) => (
                    <span
                      key={tIdx}
                      className="text-[9px] px-2 py-0.5 rounded border border-white/5 bg-white/5 text-[#b0a99e] font-light"
                    >
                      {term}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>

      {/* Clean Minimal Archival Footer */}
      <footer className="pt-6 border-t border-white/5 flex items-center justify-between text-[11px] text-[#706a61] pointer-events-auto font-['Newsreader']">
        <span>Lexora Jurisprudence Archive</span>
        <span className="italic text-[#8c857a]">Connected Network of Law</span>
      </footer>

      {/* Archive Settings / Specifications Drawer */}
      <ArchiveSettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        audioEnabled={audioEnabled}
        onToggleAudio={onToggleAudio}
      />
    </div>
  );
};
