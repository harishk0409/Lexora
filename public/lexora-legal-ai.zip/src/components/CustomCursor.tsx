import React, { useEffect, useState } from 'react';

export const CustomCursor: React.FC = () => {
  const [pos, setPos] = useState({ x: -100, y: -100 });
  const [ringPos, setRingPos] = useState({ x: -100, y: -100 });
  const [hoverState, setHoverState] = useState<'normal' | 'interactive' | 'inspect' | 'source'>('normal');
  const [isClicking, setIsClicking] = useState(false);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    // Only enable custom cursor if fine pointer (mouse)
    const mediaQuery = window.matchMedia('(pointer: fine)');
    if (!mediaQuery.matches) return;

    let targetX = -100;
    let targetY = -100;
    let currentRingX = -100;
    let currentRingY = -100;
    let animId: number;

    const onMouseMove = (e: MouseEvent) => {
      targetX = e.clientX;
      targetY = e.clientY;
      setPos({ x: targetX, y: targetY });
      if (!visible) setVisible(true);

      // Detect hover target
      const target = e.target as HTMLElement | null;
      if (target) {
        if (target.closest('[data-cursor="inspect"]') || target.closest('[data-source-card]')) {
          setHoverState('inspect');
        } else if (
          target.closest('button') ||
          target.closest('a') ||
          target.closest('input') ||
          target.closest('[data-interactive="true"]') ||
          target.closest('[role="button"]')
        ) {
          setHoverState('interactive');
        } else {
          setHoverState('normal');
        }
      }
    };

    const onMouseDown = () => setIsClicking(true);
    const onMouseUp = () => setIsClicking(false);
    const onMouseLeave = () => setVisible(false);

    // Smooth ring lerp loop
    const lerpRing = () => {
      const ease = 0.22;
      currentRingX += (targetX - currentRingX) * ease;
      currentRingY += (targetY - currentRingY) * ease;
      setRingPos({ x: currentRingX, y: currentRingY });
      animId = requestAnimationFrame(lerpRing);
    };

    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mouseup', onMouseUp);
    document.addEventListener('mouseleave', onMouseLeave);

    animId = requestAnimationFrame(lerpRing);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mouseup', onMouseUp);
      document.removeEventListener('mouseleave', onMouseLeave);
    };
  }, [visible]);

  if (!visible) return null;

  const isInspect = hoverState === 'inspect';
  const isInteractive = hoverState === 'interactive';

  return (
    <div id="lexora-custom-cursor" className="pointer-events-none fixed inset-0 z-50 overflow-hidden">
      {/* Central precise dot */}
      <div
        className="fixed -translate-x-1/2 -translate-y-1/2 rounded-full transition-transform duration-75"
        style={{
          left: `${pos.x}px`,
          top: `${pos.y}px`,
          width: isInspect ? '4px' : '5px',
          height: isInspect ? '4px' : '5px',
          backgroundColor: isInspect ? '#d4af37' : '#f2efe9'
        }}
      />

      {/* Trailing thin ring / inspect reticle */}
      <div
        className={`fixed -translate-x-1/2 -translate-y-1/2 rounded-full border transition-all duration-200 ${
          isInspect
            ? 'w-10 h-10 border-[#d4af37]/80 bg-[#42121e]/20'
            : isInteractive
            ? 'w-9 h-9 border-[#c5a880]/60 bg-[#c5a880]/5'
            : 'w-6 h-6 border-white/25 bg-transparent'
        } ${isClicking ? 'scale-75 opacity-90' : 'scale-100 opacity-100'}`}
        style={{
          left: `${ringPos.x}px`,
          top: `${ringPos.y}px`
        }}
      >
        {isInspect && (
          <div className="absolute inset-0 flex items-center justify-center">
            {/* Crosshair marks */}
            <span className="w-1.5 h-[1px] bg-[#d4af37]/60 absolute left-0" />
            <span className="w-1.5 h-[1px] bg-[#d4af37]/60 absolute right-0" />
            <span className="h-1.5 w-[1px] bg-[#d4af37]/60 absolute top-0" />
            <span className="h-1.5 w-[1px] bg-[#d4af37]/60 absolute bottom-0" />
          </div>
        )}
      </div>
    </div>
  );
};
