import React, { useState, useEffect } from 'react';
import { LivingWallpaper } from './components/LivingWallpaper';
import { CustomCursor } from './components/CustomCursor';
import { LandingView } from './components/LandingView';
import { ThinkingSequence } from './components/ThinkingSequence';
import { ResearchWorkspace } from './components/ResearchWorkspace';
import { DocumentDrawer } from './components/DocumentDrawer';
import { KnowledgeGraphModal } from './components/KnowledgeGraphModal';
import { SelfLearningModal } from './components/SelfLearningModal';
import { LegalResearchResponse, EvidenceSource, LegalDomain, ResearchStage } from './types';
import { PRESET_RESEARCH_DOSSIERS, generateMockResearch } from './data/mockLegalArchive';
import { sound } from './utils/audio';

export default function App() {
  const [viewMode, setViewMode] = useState<'landing' | 'thinking' | 'research'>('landing');
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [thinkingStage, setThinkingStage] = useState<ResearchStage>('idle');
  const [currentResearch, setCurrentResearch] = useState<LegalResearchResponse>(
    PRESET_RESEARCH_DOSSIERS['contract-section-10']
  );
  const [selectedSource, setSelectedSource] = useState<EvidenceSource | null>(null);
  const [isGraphOpen, setIsGraphOpen] = useState(false);
  const [isSelfLearningOpen, setIsSelfLearningOpen] = useState(false);
  const [historyList, setHistoryList] = useState<string[]>([
    'What are the five exceptions to murder under IPC Section 300?',
    'How does Article 21 protect life and personal liberty against arbitrary state action?',
    'How are Digital Signatures verified under IT Rules 2000?'
  ]);
  const [audioEnabled, setAudioEnabled] = useState(false);
  const [activeDomain, setActiveDomain] = useState<LegalDomain>('Criminal');

  // Audio mute toggle
  const handleToggleAudio = () => {
    const nextState = !audioEnabled;
    setAudioEnabled(nextState);
    sound.enabled = nextState;
    if (nextState) {
      sound.playArchivePulse();
    }
  };

  // Execute inquiry search with real RAG backend + cinematic thinking sequence
  const startResearch = async (query: string, domainHint?: LegalDomain) => {
    setSearchQuery(query);
    setViewMode('thinking');
    setThinkingStage('exploring');

    // Add to history if unique
    if (!historyList.includes(query)) {
      setHistoryList(prev => [...prev, query]);
    }

    // Thinking sequence steps
    setTimeout(() => {
      setThinkingStage('connecting');
    }, 550);

    setTimeout(() => {
      setThinkingStage('assembling');
    }, 1150);

    setTimeout(() => {
      setThinkingStage('forming');
    }, 1750);

    try {
      // Query our full-stack RAG model
      const ragPromise = fetch('/api/rag/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query, domain: domainHint })
      }).then(res => {
        if (!res.ok) throw new Error(`HTTP error ${res.status}`);
        return res.json();
      });

      // Maintain minimum duration for the cinematic thinking sequence
      const delayPromise = new Promise(resolve => setTimeout(resolve, 2200));
      const [response] = await Promise.all([ragPromise, delayPromise]);

      if (response && response.holdingSummary) {
        setCurrentResearch(response);
        setActiveDomain(response.domain || domainHint || 'Criminal');
      } else {
        const fallback = generateMockResearch(query, domainHint);
        setCurrentResearch(fallback);
        setActiveDomain(fallback.domain);
      }
    } catch (err) {
      console.warn('RAG backend call error, falling back to local synthesizer:', err);
      const fallback = generateMockResearch(query, domainHint);
      setCurrentResearch(fallback);
      setActiveDomain(fallback.domain);
    } finally {
      setThinkingStage('completed');
      setViewMode('research');
      sound.playResolveHarmonic();
    }
  };

  // User feedback loop to train the self-learning model
  const handleFeedback = async (chunkId: string, vote: 'up' | 'down') => {
    try {
      const res = await fetch('/api/rag/feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: searchQuery,
          chunkId,
          vote
        })
      });
      const data = await res.json();
      if (data.newWeight && currentResearch?.selfLearningTelemetry) {
        setCurrentResearch(prev => ({
          ...prev,
          selfLearningTelemetry: {
            ...prev.selfLearningTelemetry!,
            adaptationCount: (prev.selfLearningTelemetry?.adaptationCount || 0) + 1,
            activeWeights: {
              ...(prev.selfLearningTelemetry?.activeWeights || {}),
              [chunkId]: data.newWeight
            }
          }
        }));
      }
    } catch (err) {
      console.error('Feedback recording failed:', err);
    }
  };

  const handleDomainSelect = (domain: LegalDomain) => {
    setActiveDomain(domain);
    let queryForDomain = `Jurisprudence and leading precedents in ${domain} Law`;
    if (domain === 'Criminal') queryForDomain = 'What are the five exceptions to murder under IPC Section 300?';
    else if (domain === 'Constitution') queryForDomain = 'How does Article 21 protect life and personal liberty against arbitrary state action?';
    else if (domain === 'Contract') queryForDomain = 'Essential elements of a valid contract';
    else if (domain === 'Torts' || domain === 'Case Law') queryForDomain = 'Find cases concerning negligence';

    startResearch(queryForDomain, domain);
  };

  return (
    <div className="relative min-h-screen w-full bg-[#0a0b0e] text-[#f5f2eb] font-['Plus_Jakarta_Sans'] overflow-x-hidden selection:bg-[#42121e] selection:text-[#faedd0]">
      {/* 1. Custom Interactive Cursor */}
      <CustomCursor />

      {/* 2. Signature Feature: The Living Interactive Legal Wallpaper */}
      <LivingWallpaper
        stage={thinkingStage}
        searchFocused={isSearchFocused}
        searchQuery={searchQuery}
        activeDomain={activeDomain}
        onCanvasClick={() => {
          sound.playArchivePulse();
        }}
      />

      {/* 3. Main Views Container */}
      <div className="relative z-10 min-h-screen flex flex-col">
        {viewMode === 'landing' && (
          <LandingView
            onSearch={(q) => startResearch(q)}
            onSelectPrompt={(q) => startResearch(q)}
            onFocusChange={setIsSearchFocused}
            onQueryChange={setSearchQuery}
            audioEnabled={audioEnabled}
            onToggleAudio={handleToggleAudio}
            onOpenGraphDirect={() => setIsGraphOpen(true)}
            onOpenSelfLearning={() => setIsSelfLearningOpen(true)}
          />
        )}

        {viewMode === 'thinking' && (
          <ThinkingSequence
            stage={thinkingStage}
            query={searchQuery}
            onComplete={() => setViewMode('research')}
          />
        )}

        {viewMode === 'research' && currentResearch && (
          <ResearchWorkspace
            research={currentResearch}
            onNewSearch={(q) => startResearch(q)}
            onSelectSource={(source) => setSelectedSource(source)}
            onOpenGraph={() => setIsGraphOpen(true)}
            onOpenSelfLearning={() => setIsSelfLearningOpen(true)}
            onFeedback={handleFeedback}
            onBackToLanding={() => {
              setViewMode('landing');
              setThinkingStage('idle');
            }}
            activeDomain={activeDomain}
            onSelectDomain={handleDomainSelect}
            historyList={historyList}
            onSelectHistoryItem={(q) => startResearch(q)}
          />
        )}
      </div>

      {/* 4. Pull-Out Document Reader Drawer */}
      {selectedSource && (
        <DocumentDrawer
          source={selectedSource}
          onClose={() => setSelectedSource(null)}
          onInspectNode={(label) => {
            setSelectedSource(null);
            setIsGraphOpen(true);
          }}
        />
      )}

      {/* 5. Legal Knowledge Graph Modal */}
      {isGraphOpen && currentResearch && (
        <KnowledgeGraphModal
          nodes={currentResearch.graphNodes}
          edges={currentResearch.graphEdges}
          onClose={() => setIsGraphOpen(false)}
          activeDomain={activeDomain}
        />
      )}

      {/* 6. Self-Learning RAG Intelligence & Ingested Corpus Explorer */}
      <SelfLearningModal
        isOpen={isSelfLearningOpen}
        onClose={() => setIsSelfLearningOpen(false)}
        onSelectQuery={(q) => startResearch(q)}
      />
    </div>
  );
}
