import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import { generateLegalResearch, searchCorpus } from './server/rag/ragEngine.js';
import { learningStore } from './server/rag/learningStore.js';
import { LEGAL_CORPUS } from './server/corpus/legalCorpus.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '10mb' }));

  // ==========================================
  // RAG API ROUTES
  // ==========================================

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      service: 'Lexora RAG Backend',
      corpusSize: LEGAL_CORPUS.length,
      selfLearningActive: true
    });
  });

  // Query RAG pipeline
  app.post('/api/rag/query', async (req, res) => {
    try {
      const { query, domain } = req.body;
      if (!query || typeof query !== 'string' || !query.trim()) {
        return res.status(400).json({ error: 'Query string is required' });
      }

      const result = await generateLegalResearch(query.trim(), domain);
      res.json(result);
    } catch (err: any) {
      console.error('RAG query processing failed:', err);
      res.status(500).json({
        error: 'Failed to process legal research query',
        details: err?.message || String(err)
      });
    }
  });

  // Self-learning feedback loop
  app.post('/api/rag/feedback', (req, res) => {
    try {
      const { query, chunkId, vote, reason } = req.body;
      if (!chunkId || (vote !== 'up' && vote !== 'down')) {
        return res.status(400).json({ error: 'Valid chunkId and vote ("up"|"down") required' });
      }

      const outcome = learningStore.applyFeedback({
        query: query || '',
        chunkId,
        vote,
        reason,
        timestamp: new Date().toISOString()
      });

      res.json({
        success: true,
        message: `Self-learning model updated: weight for ${chunkId} adjusted to ${outcome.newWeight}`,
        ...outcome
      });
    } catch (err: any) {
      console.error('Feedback processing error:', err);
      res.status(500).json({ error: 'Failed to record learning feedback' });
    }
  });

  // Self-learning telemetry and corpus stats
  app.get('/api/rag/stats', (req, res) => {
    try {
      const state = learningStore.getState();
      const topWeighted = Object.entries(state.sectionWeights)
        .map(([chunkId, weight]) => {
          const chunk = LEGAL_CORPUS.find(c => c.id === chunkId);
          return {
            chunkId,
            weight,
            title: chunk ? `${chunk.sectionOrArticle}: ${chunk.title}` : chunkId
          };
        })
        .sort((a, b) => b.weight - a.weight)
        .slice(0, 8);

      res.json({
        version: state.version,
        totalQueriesProcessed: state.totalQueriesProcessed,
        learningCyclesRun: state.learningCyclesRun,
        weightAdaptationsCount: state.weightAdaptationsCount,
        corpusCount: LEGAL_CORPUS.length,
        minedEdgesCount: state.minedEdges.length,
        exemplarsCount: state.exemplars.length,
        topWeightedSections: topWeighted
      });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to retrieve telemetry stats' });
    }
  });

  // Browse authoritative legal corpus chunks
  app.get('/api/rag/corpus', (req, res) => {
    try {
      const search = (req.query.search as string) || '';
      const domain = req.query.domain as string;

      if (!search && !domain) {
        return res.json({
          total: LEGAL_CORPUS.length,
          chunks: LEGAL_CORPUS.map(c => ({
            id: c.id,
            sourceDoc: c.sourceDoc,
            domain: c.domain,
            sectionOrArticle: c.sectionOrArticle,
            title: c.title,
            keyTerms: c.keyTerms,
            crossReferences: c.crossReferences,
            currentWeight: learningStore.getSectionWeight(c.id, c.importanceWeight)
          }))
        });
      }

      const results = searchCorpus(search || '', domain, 15);
      res.json({
        total: results.length,
        chunks: results.map(r => ({
          ...r.chunk,
          relevanceScore: r.score,
          learnedMultiplier: r.learnedMultiplier,
          matchedKeywords: r.matchedKeywords
        }))
      });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to query corpus' });
    }
  });

  // ==========================================
  // VITE MIDDLEWARE / PRODUCTION STATIC FALLBACK
  // ==========================================
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Lexora Legal AI Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
